<?php session_start();
$nm=$_POST['nm'];
$pwd=$_POST['pwd'];
$con=mysql_connect("localhost","root","");
$db=mysql_select_db("mensware",$con);

$qry="select * from admin_login where adminname='$nm' and password='$pwd'";
	//echo $qry;
$res=mysql_query($qry);
//$row=mysql_fetch_array($res);
if(mysql_num_rows($res)>0)
	{
		$_SESSION['name']=$row['name'];
		header('location:welcome.php');
			}
				else
					{
						$_SESSION['msg']="please enter name or password....";
							header('location:login.php');
							}
							?>