<?php include('include/config.php');
$pro_id=$_REQUEST['id'];
$select_qry="select * from product";
$test=mysql_query($select_qry);
$row=mysql_fetch_array($test);
$sel_company="select * from company";
$res_sel_company=mysql_query($sel_company);
$row1=mysql_fetch_array($res_sel_company);
?>
<?php include('include/header1.php'); ?>
<link rel="stylesheet" href="css/style1.css"/>
<html>
<body bgcolor="#CC0099">
<div id="round_cornar">
<div id="product_desc_box">
<div id="round_corner_icon">
<a href="product.php">
<div class="pro_img"><?php echo "<img src='".$row['pro_img']."' height='400' width='400'></img>"; ?>


</a></div>

<div class="feature_left">company name:</div>
<div class="feature_right"><?php echo $row1['com_name']; ?></div>
<hr/>
<div class="feature_left">product name:</div>
<div class="feature_right"><?php echo $row['pro_name'];?></div>
<hr/>

<div class="feature_left">price:</div>
<div class="feature_right"><?php echo $row['price'];?></div>
<hr/>
<p class="button left"><a href="buy_now.php?id=<?php echo $row['pro_id'];?>">Buy</a></p>
</div>
<div class="clear"></div>
<div class="product_desc">
<h2> information</h2>
<hr/>
<p>
<?php echo $row ['this is a brand item']; ?>
</p>
</div></div>
</body>
</html>
<?php include('include/footer1.php'); ?>
