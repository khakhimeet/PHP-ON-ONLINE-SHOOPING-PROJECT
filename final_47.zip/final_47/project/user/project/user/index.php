<?php include('include/header1.php');?>
<link rel="stylesheet" href="css/style.css" />
<html>
<body>
<br> <br> <br>
<div id="round_corner_welcome">
<div id="round_corner_icon">

<a href="index.php">
<img src="img/index.jpg" height="100" width="100" /> 
</a></div>

<div id="round_corner_icon">
<a href="product.php">
<img src="img/order.jpg" height="100" width="100" />
</a></div>

<div id="round_corner_icon">
<a href="aboutus.php">
<img src="img/a1.jpg" height="100" width="100" />
</a></div>

<div id="round_corner_icon">
<a href="feedback.php">
<img src="img/feedback.jpg" height="100" width="100" /> 
</a></div>

<div id="round_corner_icon">
<a href="user_login.php">
<img src="img/User.png" height="100" width="100" />
</a></div>

<div id="round_corner_icon">
<a href="./admin/login.php">
<img src="img/admin.jpg" height="100" width="100" />
</a></div></div>
</body>
</html>
<br><br><br>
<?php include('include/footer.php'); ?>
