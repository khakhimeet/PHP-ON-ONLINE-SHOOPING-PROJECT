	
	<?php include('include/header.php'); ?>
	<link rel="stylesheet" href="" />
    <div id="container">
    <div id="content">
    <div id="round_corner">
    <div class-"box_head1">feedback</div>
    <div class="table">
    <table width="100%" border="2" cellspacing="1" cellpadding="4" bgcolor="#99CCFF">
    <tr>
    <th width="13"><input type="checkbox" class="checkbox" /></th>
    <th>name</th>
    <th>email</th>
    <th>comment</th>
    <th width="110" class="kc">control</th>
    </th>
    </tr>
    <?php
	$con=mysql_connect("localhost","root","");
	$db=mysql_select_db(mensware,$con);
	$qry="select user_id,user_nm,eid, comment from feedback";
	$res=mysql_query($qry);
	while($row=mysql_fetch_array($res))
	{
		?>
        <tr>
		<th width="13"><input type="checkbox" class="checkbox" /></th>
        <th><?php echo $row['user_nm']?></th>
        <th><?php echo $row['eid']?></th>
        <th><?php echo $row['comment']?></th>
        <th width="70" class="kc"><a href="delfeedbck.php ? id=<?php echo $row['user_id']?>" class="icodel">delete</a></th>
        </tr>
        <?php
		}
		?>
        </table>
       </div>
       </div>
       </div>
       </div>
       <?php include('include/footer1.php');?>