<?php include('include/header1.php'); ?>
<link rel="stylesheet" href="css/style.css" />
<html>
<body>
<div id="round_corner">
<center>
<h2>AboutUs </h2></center>
<hr/>
<div class="cms_contant">
<center>
<marquee behavior="alternate"><img width="100%" height="130%" src="img/2.jpg"></img></marquee></center>
<h3> welcome to the online shoping center in our website clothes are branded  </h3>

</div>
</div>
</body>
</html>
<?php include('include/footer1.php'); ?>

       