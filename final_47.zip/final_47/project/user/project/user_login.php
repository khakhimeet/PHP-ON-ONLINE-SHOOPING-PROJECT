<?php include('include/header1.php');
    
	  ?>
	  <link rel="stylesheet" href="css/style1.css">
      <html>
      <head>
      <title> ONLINE SHOPPING </title>
      </head>
      <body background="img/6.jpg">
      <div id="round_cornar_login">
      <div class="page_title"> Login </div>
      <form action="login1.php" enctype="multipart/form-data" method="post">
     
       <div class="formrowgrey">
       <div class="formleft_login"><strong>username</strong><span id="es"></span></div>
       <div class="formright">
       <input class="textbox" type="text" name="nm" placeholder ="enter your name.." required />
       </div></div>
       <div class="formrow">
       <div class="formleft_login"><strong>Password</strong><span id="ps"></span></div>
       
       <div class="formright">
       <input class="textbox" type="password" id="password" name="pwd" placeholder="Enter your password.." required/>
       </div></div>
       <div class="formrow">
       <div class="formleft_login">&nbsp;</div>
       <div class="formright">
       <div class="buttons">
       <input class="button_login" type="submit" id="password" name="submit" value="login" style="background-color:#FFFF00" />
       <input type="reset" class="button_login" value="reset" />
       </div></div></div>
       <div class="formrowgrey">
       <div class="formleft_login"><samp>&nbsp;</samp></div>
       <div class="formright">
       <a href="register1.php" style="color:#666666">Create New Account</a>
       </div>
       </div>
       </form>
       </div>
       </body>
       </html>
       <br><br><br><br><br>
       <?php include("include/footer1.php");?>
       
                                                                                                                                               
                                                                                                                                                   
                                                                                                                                                   
                                                                                                                                                   
                                                                                                                                                   
                                                                                                                                                   
                                                                                                                                                   
                                                                                                                                                   
                                                                                                                                                   
                                                                                                                                                   
                                                                                                                                                   
                                                                                                                                                   
                                                                                                                                                   
                                                                                                                                                   
                                                                                                                                                   
                                                                                                                                                   
                                                                                                                                                   
                                                                                                                                                   
                                                                                                                                                   
                                                                                                                                                   
                                                                                                                                                   
                                                                                                                                                   
                                                                                                                                                   