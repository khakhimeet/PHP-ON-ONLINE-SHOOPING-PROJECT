<?php
$name=$_REQUEST['id'];
$con=mysql_connect("localhost","root","");
$db=mysql_select_db('mensware',$con);
$qry="delete from product where pro_id='$name'";
$res=mysql_query($qry);
header('location:product_list.php');
?>