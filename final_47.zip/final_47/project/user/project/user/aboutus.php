<?php include('include/header.php'); ?>
<link rel="stylesheet" href="css/style1.css" />
<html>
<body>
<div id="round_corner">
<center>
<h2>AboutUs </h2></center>
<hr/>
<div class="cms_contant">
<center>
<img width="30%" height="30%" src="a1.jpg"></img></center>
<h3> welcome to the online shoping center </h3>
</div>
</div>
</body>
</html>
<?php include('include/footer.php'); ?>

       