<link rel="stylesheet" href="./css/style.css"/>
<html>
<body>
<div id="footer">
<table width="100%" height="15%" border="10" bgcolor="#FFFF00">
<tr>
<td height="60">
<div class="shell">
<span class="reight">BUSICNESS MEN:JAY DUDHAGARA,MEET KHAKHI</span>
</div>
</td>
</tr>
</table>
</div>
</body>
</html>
