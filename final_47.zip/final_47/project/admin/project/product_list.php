
  <?php include('include/header.php'); ?>
  <link rel="stylesheet" href="" />
  <div id="container">
  <div id="content">
  <div id="round_corner">
  <div id="add_new">
<a href="product.php">
<input type="button" value="Add Product" class="button" />
</a>
</div>

<marquee behavior="alternate"><img src="img/2.jpg" /></marquee></img>
   <div class="table">
   <table width="100%" border="3" cellspacing="2" cellpadding="3" background="img/20.jpg">
   <tr>
   <th width="13">
   <input type="checkbox"  class="checkbox" />
   </th>
   
   <th>pro_name</th>
   <th>price</th>
   <th> pro_img</th>
   <th width="110" class="ac">Control</th>
   </tr>
   <?php
   $con=mysql_connect("localhost","root","");
   $db=mysql_select_db('mensware',$con);
   $qry="select pro_id,pro_name,price,pro_img from product";
   $res=mysql_query($qry);
   while($row=mysql_fetch_array($res))
   {
     ?>
     <tr>
     <th width="13" ><input  type="checkbox" class="checkbox" /></th>
		
     <th><?php echo $row['pro_name']?></th>
     <th><?php echo $row['price']?></th>
     <th><?php echo "<img src='".$row['pro_img']."' height='40' width='60'></img>"; ?></th>
     <th width="110" class="ac"><a href="delproduct.php?id=<?php echo $row['pro_id'] ?>" class="ico del" >delete</a>
     <a href="update_product.php?id=<?php echo $row['pro_id'] ?>" class="ico del" >edit</a></th>
     </tr>
     <?php
	  }
	  ?>
      </table>
      </div>
      </div>
      </div>
      </div>
      <?php include('include/footer1.php'); ?>
      