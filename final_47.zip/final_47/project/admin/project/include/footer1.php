<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title> footer </title>
<link rel="stylesheet"  type="text/css" href="css/style3.css" />
</head>
<body>
<div class="footer-main-div">
<div class="footer-social-icons">
<ul>
<li><a></a></li>
</ul></div>

<div class="footer-menu-one">
<ul>
<li><a href="#">Home</a></li>
<li><a href="#">Product</a></li>
<li><a href="#">Aboutus</a></li>
<li><a href="#">feedback</a></li>

</ul></div>

<div class="footer-bottom">
<marquee direction="right"><font color="#99CC33"><font face="Century Gothic"> Design By: Meet Khakhi & jay dudhagara </a></marquee>
</div>
</body>
</html>


