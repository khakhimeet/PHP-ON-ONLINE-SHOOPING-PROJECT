<?php include('include/header1.php');?>
<?php include('include/config.php');?>
<div id="round_cornar">
<?php
   $page=1;
   $limit=12;
   if(isset($_REQUEST['page']))
   {
    $page=$_REQUEST['page'];
	$start=$limit*($page-1);
	}
	else
	{
	   $start=0;
	   }
	   $qry="select * from product";
	   
	   $res=mysql_query($qry);
	   while($row1=mysql_fetch_array($res))
	   {
	    echo "<img src='".$row1['pro_img']."' height='150' width='190'></img>";?>
		 <ul>
		 <li> product_id : <?php echo $row1['pro_id'];?></li>
		 <li> product_name: <?php echo $row1['pro_name'];?></li>
		 <li> PRICE : <?php echo $row1['price'];?></li>
		 </ul>
       <?php  }
	   
	   $qry1="select * from company";
	   $res1=mysql_query($qry1);
	   while($row=mysql_fetch_array($res1))
	   {
	     ?>
		 <link rel="stylesheet" href="css/style4.css" />
         <div id="product_box">
         <div id="product_cm">
         <h2>
		 <?php echo $row['com_name'];?>
		 </h2>
		 </div>
         
		 <p class="button"><a href="product.php?id=<?php echo $row['pro_id'];?>">READ MORE </a></p>
		 </div>
		 <?php 
		 } ?>
		 </div>
         
		 <?php include("include/footer1.php"); ?>