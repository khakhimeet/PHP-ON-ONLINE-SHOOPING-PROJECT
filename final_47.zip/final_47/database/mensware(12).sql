-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 08, 2019 at 11:31 AM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mensware`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_cart`
--

CREATE TABLE IF NOT EXISTS `add_cart` (
  `add_id` int(10) NOT NULL,
  `pro_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `qty` int(20) NOT NULL,
  `price` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_cart`
--


-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE IF NOT EXISTS `admin_login` (
  `adminname` varchar(20) NOT NULL,
  `password` varchar(5) NOT NULL,
  `email_id` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`adminname`, `password`, `email_id`) VALUES
('jay patel', '1772', 'jaypatel1772@gmil.co'),
('jay patel', '1772', 'jaypatel1772@gmil.co');

-- --------------------------------------------------------

--
-- Table structure for table `client_login`
--

CREATE TABLE IF NOT EXISTS `client_login` (
  `name` varchar(25) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client_login`
--


-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE IF NOT EXISTS `company` (
  `com_id` varchar(10) NOT NULL,
  `com_name` varchar(20) NOT NULL,
  PRIMARY KEY (`com_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`com_id`, `com_name`) VALUES
('1', 'levi''s'),
('2', 'raynod'),
('3', 'spykar'),
('4', 'jack&jeans'),
('5', 'polo'),
('', 'jay');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `user_id` int(10) NOT NULL,
  `user_nm` varchar(20) NOT NULL,
  `eid` varchar(30) NOT NULL,
  `comment` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`user_id`, `user_nm`, `eid`, `comment`) VALUES
(1, 'jay', 'jaypatel1772@gmil.com', 'good');

-- --------------------------------------------------------

--
-- Table structure for table `new_product`
--

CREATE TABLE IF NOT EXISTS `new_product` (
  `npro_id` int(10) NOT NULL,
  `npro_name` varchar(10) NOT NULL,
  `nprice` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `new_product`
--


-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` varchar(30) NOT NULL,
  `pro_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--


-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `pro_id` int(10) NOT NULL AUTO_INCREMENT,
  `pro_name` varchar(20) NOT NULL,
  `price` int(5) NOT NULL,
  `pro_img` text NOT NULL,
  PRIMARY KEY (`pro_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pro_id`, `pro_name`, `price`, `pro_img`) VALUES
(16, 'shirt', 123, 'img/pro_img/b1.jpg'),
(20, 'shirt', 999, 'img/pro_img/b6.jpg'),
(19, 'shirt', 960, 'img/pro_img/b6.jpg'),
(14, 'paint', 52, 'img/pro_img/b5.jpg'),
(15, 'paint', 202, 'img/pro_img/b9.jpg'),
(17, 'shirt', 203, 'img/pro_img/b1.jpg'),
(18, 'paint', 233, 'img/pro_img/b147.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `register_user`
--

CREATE TABLE IF NOT EXISTS `register_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_nm` varchar(30) NOT NULL,
  `user_fnm` varchar(30) NOT NULL,
  `user_lnm` varchar(30) NOT NULL,
  `eid` varchar(30) NOT NULL,
  `pwd` varchar(30) NOT NULL,
  `content_no` varchar(10) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(10) NOT NULL,
  `pincode` int(10) NOT NULL,
  `profile-picture` text NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `register_user`
--

