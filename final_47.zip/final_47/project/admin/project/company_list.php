
<?php include('include/header.php');?>
<link rel="stylesheet" href="" />
<div id="container">
<div id="content">
<div id="round_corner">
<div id="add_new">
<a href="addcompany.php">
<input type="button" value="addcompay" class="button" />
</a>
</div>
<div class="box_head"> <marquee style="background:#99FFFF"><font size="+6"><font color="#000000">current company</div></marquee></font></font>
<div class="table">
<table width="100%" border="3" cellpadding="2" cellspacing="2" background="img/20.jpg">
<tr>
<th width="13"><input type="checkbox" class="checkbox" /></th>
<th>company name</th>
<th width="110" class="kc">control</th></tr>
<?php
$con=mysql_connect("localhost","root","");
$db=mysql_select_db('mensware',$con);
$qry="select * from company";
$res=mysql_query($qry);
while($row=mysql_fetch_array($res))
{
?>
<th width="13"><input type="checkbox" class="checkbox" /></th>
<th><?php echo $row['com_name']?></th>
<th width="110" class="kc"><a href="delcompany.php ? id=<?php echo $row['com_id']?>" class="icodel">delete</a>
<a href="update_company.php ? id=<?php echo $row['com_id']?>" class="icodel">edit</a></th>
</tr>
<?php
}
?>
</table>
</div>
</div>
</div>
</div>
<?php include('include/footer1.php')?>