<?php include('include/header1.php'); ?>
<link rel="stylesheet" href="css/style.css"/>
<div id="container">
<div id="round_corner_login">
<?php
if(isset($_SESSION['msg']))
{
echo $_SESSION['msg'];
unset($_SESSION['msg']);
}?>
<form method="post" action="login1.php">
<div class="box_head">login</div>
<div class="fromrow_login">
<div><strong>user name</strong></div>
<input type="name" name="nm" class="size5" place hloder="enter admin name" required/>
</div>
<div class="formrowgrey_login">
<div><strong>password</strong></div>
<input type="password" name="pwd" class"size4" place holder="enter admin password!!!" reaurired/>
</div>
<div class="buttons">
<input type="submit" name="submit" class="button" value="login" />
<input type="reset" class="button" value="reset" />
</div>
</form>
</div>
</div>
<?php include('include/footer1.php'); ?>