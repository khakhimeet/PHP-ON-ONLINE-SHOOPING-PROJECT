<html>
<head>
<title>Online Shoping page</title>
<link rel="stylesheet" type="text/css" href="css/style2.css" />
</head>
<body>
<div class="head">
<marquee><h1><font size="+6">MEN'S WARE</font></h1></marquee>
<div class="nav">
<ul class="main-menu">
<li>Home</li>
<li><a href="product_disp1.php">Product</li></a>
<li><a href="feedback.php">Feedback</li></a>
<li><a href="aboutus.php">Aboutus</li></a>
<li><a href="user_login.php">Login</li></a>
<li>Admin</li>
</ul>
</div>
</body>
</html>

