<?php include('include/header.php');?>
<link rel="stylesheet" href=""/>
<div id="container">
<div id="round_corner_login">
<?php
if(isset($_SESSION['msg']))
{
echo $_SESSION['msg'];
unset($_SESSION['msg']);
}?>
<html>
<body border='2'>
<form method="post" action="login1.php">

<center>
<font color="#99CCCC"><font size="+10"><marquee style="background:#666666">login</font></font></marquee>
<div class="fromrow_login">
<div><strong>user name</strong></div>
<input type="name" name="nm" class="size5" placeholder="enter admin name...." style="background:#CCFF99" required/>
</div>
<div class="formrowgrey_login">
<div><strong>password</strong></div>
<input type="password" name="pwd" class"size4" placeholder="enter admin password!!!"  style="background:#CCFF99" required/>
</div>
<div class="buttons">
<input type="submit" name="submit" class="button" value="login"  style="background:#99FFFF" />
<input type="reset" class="button" value="reset" />
</div></center>
</form>
</div>
</div></body></html>
<br>
<br>
<?php include('include/footer1.php'); ?>