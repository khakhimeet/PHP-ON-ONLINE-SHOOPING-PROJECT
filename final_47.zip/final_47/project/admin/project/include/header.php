<html>
<head>
<title>Online Shoping page</title>
<link rel="stylesheet" type="text/css" href="css/style1.css" />
</head>
<body>
<div class="head">
<marquee style="background:#9999CC"><font color="#99CCCC"><h1>Men's ware </h1></font></marquee>
<div class="nav">
<ul class="main-menu">
<li><a href="welcome.php">Home</li></a>
<li><a href="admin.php">Admin</a></li>
<li><a href="usermanagement.php">Registeruser</a></li>
<li><a href="company_list.php">company</li></a>
<li><a href="product_list.php">product</li></a>
<li><a href="order.php">order</li></a>

</ul>
</div>
</body>
</html>

