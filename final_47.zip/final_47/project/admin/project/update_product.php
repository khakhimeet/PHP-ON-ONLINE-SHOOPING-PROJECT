<?php
    $id=$_REQUEST['id'];
	$con=mysql_connect("localhost","root","");
	$db=mysql_select_db('mensware',$con);
	if(isset($_POST['submit']))
	{
	$chk=$_POST['chk'];
	
	$pro_name=$_POST['pro_name'];
	
	$img=$_POST['pro_img'];
	
	$price=$_POST['price'];
	
	
	
	if($_POST['submit']=='submit')
	{
	  if($chk)
	  {
	  $path="img/pro_img/".basename($_FILES['pro_img']['name']);
	  move_uploaded_file($_FILES['pro_img']['tmp_name'],$path);
	  
	  $qry="update product set pro_name='$pro_name',pro_img='$path',price ='$price where pro_id=$id";
	  }
	  else
	  {
	     $qry="update product set pro_name='$pro_name',pro_img='$path',price ='$price'  where pro_id=$id";
		 }
		 $res=mysql_query($qry);
		 
		 if($res)
		 {
		    header('location:product_list.php');
			}
			else
			{
			  echo"not insert";
			  }
			  }
			  else
			  {
			  echo"before value is submit";
			  }
			  }
			  ?>
              <?php include('include/header.php'); ?>
              <link rel="stylesheet" href="" />
              <div id="container">
              <div class="shell">
              <div id="content">
              <div id="round_corner">
              <div class="box_head1"> update product </div>
              <form method="post" action="" enctype="multipart/form-data">
              <?php
			    $qry1="select pro_id,pro_name,price,pro_img from product";
				$res1=mysql_query($qry1);
				$row=mysql_fetch_array($res1);
				
				$qry2="select * from company";
				
				$res2=mysql_query($qry2);
				$row2=mysql_fetch_array($res2);
				?>
				<div class="formrowgrey">
                <div class="formleft">Company Name*</div>
                <div class="formright">
                <input type="text" name="com_name" class="textbox" value="<?php echo $row2['com_name']?>" readonly="readonly" />
                </div></div>
                
                
                <div class="formrow">
         <div class="formleft">pnm*</div>
         <div class="formright">
         <input type="text" name="pro_name" class="textbox" placeholder="productname" required /></div>
         
         <div class="formrow">
         <div class="formleft">price*</div>
         <div class="formright">
         <input type="text" name="price" class="textbox" placeholder="price in rs." required /></div>
         
         <div class="formrow">
         <div class="formleft">product image*</div>
         <div class="formright">
         <input type="file" name="pro_img" class="textbox" /></div>
         
         <div class="buttons">
        
         <input type="submit" name="submit" class="button" value="submit" />
         <input type="reset" class="button" value="reset" />
                </div>
                
                </form>
               
                </div>
                <?php include('include/footer.php'); ?>
                <script type="text/javascript">
				function fun()
				{
				   Var a=document.getElementById('d1');
				   d1.innerHTML="<input type='file' id='f1' name='pro_img'>";
				   }
				   function funval()
				   {
				   var b=document.getElementById('f1');
				   
                var c=document.getElementById('chk');
				if(b.value==""&& c.checked)
				{
				 alert("select Image");
				 return false;
				 }
				 return true;
				 }
				 </script>
				   
                
                
                
                