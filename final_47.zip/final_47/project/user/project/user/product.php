<?php include('include/config.php');
$pro_id=$_REQUEST['id'];
$select_qry="SELECT * FROM `product` WHERE pro_id='$pro_id'";
$test=mysql_query($select_qry);
$row=mysql_fetch_array($test);
$sel_company="SELECT * FROM `company` WHERE com_id='$com_id'";
$res_sel_company=mysql_query($sel_company);
$row1=mysql_fetch_array($res_sel_company);
?>
<?php include('include/header.php'); ?>
<link rel="stylesheet" href="css/style1.css"/>
<html>
<body>
<div id="round_cornar">
<div id="product_desc_box">
<div class="product_img">
<?php echo"<img src='admin/".$row['pro_img']." ' height='400' width='400' ></img>";?>
</div>
<div class="feature_left">company name :</div>
<div class="feature_right"><?php echo $row1 ['com_nm']; ?></div>
<hr/>
<div class="feature_left">pro_price :</div>
<div class="feature_right"><?php echo $row['pro_price'];?></div>
<hr/>
<div class="feature_left">pro_id :</div>
<div class="feature_right"><?php echo $row['pro_id'];?></div>
<hr/>
<p class="button left"><a href="buy_now.php?id=<?php echo $row['pro_id'];?>">Buy</a></p>
</div>
<div class="clear"></div>
<div class="product_desc">
<h2> information</h2>
<hr/>
<p>
<?php echo $row ['this is a brand item']; ?>
</p>
</div></div>
</body>
</html>
<?php include('include/footer.php'); ?>
