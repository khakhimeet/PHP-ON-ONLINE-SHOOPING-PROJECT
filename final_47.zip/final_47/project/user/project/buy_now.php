<?php include('include/config.php');
	
		$pro_id=$_REQUEST['id'];
		$qry="select * from product";
	   
	   $res=mysql_query($qry);
		$select_qry="select * from company";
		$res_select_qry=mysql_query($select_qry);
		
		?>
		<?php include('include/header1.php');?>
		<html>
        <script type="text/javascript" language="javascript">
		function buy_now_total(price,qty)
		{
		  var total=price*qty;
		  document.getElementByid('total').innerHTML=total;
		 }
		 function change_address()
		 {
		  var check=document.getElementByid('same').checked;
		  if(check==true)
		  {
		    document.getElementByid('d_address').style.display="none";
			document.getElementByid('dn_address').style.display="block";
		   }
		   else
		   {
		   document.getElementByid('d_address').style.display="block";
			document.getElementByid('d_address').style.display="none";
			}
			}
			</script>
            <link rel="stylesheet" href="css/style1.css"  />
            <body>
            <div id="round_cornar">
            <center>
            <h2> Shopping Details </h2>
            </center><hr/>
            
            <form id="buy_now" name="buy_now" action="bill.php" method="post" enctype="multipart/form-data" >
            <div class="table">
            <table width="100%" border="1" cellspacing="0" cellpadding="0" background="img/20.jpg">
            <tr>
            <th width="13"><input type="checkbox" class="checkbox" />
            </th>
            <th> Product Image </th>
            <th> Product Name </th>
            <th> Price </th>
            <th> Qty </th>
            <th> Total </th>
            </tr>
            <?php 
			while($row1=mysql_fetch_array($res))
			{
			$sr=1;
			
			
			
			while($row=mysql_fetch_array($res_select_qry))
			{
			  if($sr%2==0)
			  {
			    $odd="class='odd' ";
				}
				else
				{
				 $odd=" ";
				 }
				 }
				 ?>
                 <tr>
                 <?php echo $odd; ?> 
                 <td><input type="checkbox" class="checkbox"  />
                 </td>
                 <td>
                 <a href="product_view.php? id=<?php echo $row1['pro_id'];?>">
                 <img src="<?php echo $row1['pro_img'];?>" height="50" width="50" alt="no picture"  />
                 </a></td>
                 <td><?php echo $row1['pro_name'];?></td>
                 
                 <td><?php echo $row1['price'];?></td>
                 <td> 
                 <select id="qty" name="qty">
                 <?php
				   ?>
                   <option value="<?php echo $i;?>"on click="return buy_now_total (<?php echo $row['price'];?>,<?php echo $i;?>);">
				   <?php echo $i;?></option>
                   <?php
				      $i++;
					  ?>
                      </select></td>
                      <td>
                      <label id="total"><?php $row['price'];?></label></td>
                      </tr>
                      <?php
					     $sr++;
						 }?>
                         </table>
                         <hr/>
                         <div id="round_cornar_ud">
                         <h2>User Details</h2>
                         <hr/>
                         <?php
						  $id=$_SESSION['user_id'];
						  $select_user="select * from register_user where user_id=".$id;
						  $res_select_user=mysql_query($select_user);
						  ?>
                          <div class="formrowgrey">
                          <div class="formleft"><strong>Name </strong></div>
                          <div class="formright">
                          <?php echo $row_user['user_nm'];?>
                          </div></div>
                          <div class="formrow">
                          <div class="formleft"><strong>Email</strong></div>
                          <div class="formright">
                          <?php echo $row_user['eid'];?>
                          </div></div>
                          <div class="formrowgrey">
                          <div class="formleft"><strong>Contact No</strong></div>
                          <div class="formright">
                          <?php echo $row_user['contact_no'];?>
                          </div></div>
                          <div class="formrow">
                          <div class="formleft"><strong>Shopping Address</strong></div>
                          <div class="formright">
                          <?php echo $row_user['address'];?><br/>
						  <?php echo $row_user['city'];?><br/>              			  <?php echo $row_user['pincode'];?>
                          </div></div>
                          <div class="formrow">
                          <div class="formright">
                          <input type="checkbox" name="same" id="same" onClick="return change_address();"/>
                          Delivery Address is Different </div></div>
                          <div class="formrowgrey" id="d_address">
                          <div class="formleft"><strong>Delivery Address</strong></div>
                          <div class="formright">
                          <?php echo $row_user['address'];?><br/>
                          <?php echo $row_user['city'];?><br/>
                          <?php echo $row_user['pincode'];?>
		   </div></div>
           <div class="formrowgrey" id="dn_address" style="display:none;">
           <div class="formleft"><strong>DeliveryAddress</strong></div>
           <div class="formright">
           <textarea class="textarea" name="dn_address" id="dn_address"></textarea>
           </div></div>
           <div class="formrow">
           <div class="formleft">&nbsp;</div>
           <div class="formright">
           <input type="submit" name="submit" value="checkout" class="button_login" />
           </div></div></div></div>
           </form>
           </div>
           </body>
           </html>
           <?php include('include/footer1.php');?>
		   