<?php
 $con=mysql_connect("localhost","root","");
 $db=mysql_select_db('mensware',$con);
 if(isset($_POST['submit']))
 {
   $pro_id=$_POST['pro_id'];
   $pro_name=$_POST['pro_name'];
   $pro_img=$_POST['pro_img'];
   $price=$_POST['price'];
   if($_POST['submit']=='submit')
   {
   $path="img/pro_img/".basename($_FILES['pro_img']['name']); 
   move_uploaded_file($_FILES['pro_img']['tmp_name'],$path);
   $qry="insert into product(pro_name,pro_img,price)values('$pro_name','$path','$price')";
   
   $res=mysql_query($qry);
   if($res)
   {
   header('location:product_list.php');
   }
   else
   {
      echo"not insert";
	  }
	  }
	  else
	  {
	  echo"before value is submit";
	  }
	  }
	  ?>
      <?php include('include/header.php');?>
      <link rel="stylesheet" href="" />
      <div id="container">
      <div class="shell">
      <div id="content">
      <div id="round_cornar">
      <div class="box_head1">
      add new product
      </div>
      <form method="post" action="product.php" enctype="multipart/form-data">
      <div class="formrowgrey">
      <div class="formleft" name* </div>
      <div class="formright">
      <select name="company_id" class="listmenu">
      <option value=" ">select company </option>
      <?php
	    $con=mysql_connect("localhost","root","");
		$db=mysql_select_db('mensware',$con);
		$qry="select * from company";
		$res=mysql_query($qry);
		while($row=mysql_fetch_array($res))
		{
		 ?>
         <option value="<?php echo $row['com_id']; ?>">
         <?php echo $row['com_name'];?></option>
         <?php
		 }
		 ?>
         </select>
         </div>
         </div>
         <div class="formrow">
         <div class="formleft">pnm*</div>
         <div class="formright">
         <input type="text" name="pro_name" class="textbox" placeholder="productname" required /></div>
         
         <div class="formrow">
         <div class="formleft">price*</div>
         <div class="formright">
         <input type="text" name="price" class="textbox" placeholder="price in rs." required /></div>
         
         <div class="formrow">
         <div class="formleft">product image*</div>
         <div class="formright">
         <input type="file" name="pro_img" class="textbox" /></div>
         
         <div class="buttons">
        
         <input type="submit" name="submit" class="button" value="submit" />
         <input type="reset" class="button" value="reset" />
         </div>
         </form>
         </div>
         </div>
         </div></div>
         <?php include('include/footer1.php');
		 ?>
         		
   