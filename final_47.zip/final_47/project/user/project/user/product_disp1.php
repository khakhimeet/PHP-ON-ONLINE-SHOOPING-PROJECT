<?php include('include/header.php');?>
<?php include('include/config.php');?>
<div id="round_cornar">
<?php
   $page=1;
   $limit=12;
   if(isset($_REQUEST[['page']))
   {
    $page=$_REQUEST['page'];
	$start=$limit*[$page-1];
	}
	else
	{
	   $start=0;
	   }
	   $qry="select * from product";
	   $res=mysql_query($qry);
	   $qry1="select p.*,c.com_name from company c RIGHT JOIN product p on c.com_id=p.com_id where p.status='1' ";
	   $res1=mysql_query($qry1);
	   while($row=mysql_fetch_array($res1))
	   {
	     ?>
		 <link rel="stylesheet" href="CSS/style1.css" />
         <div id="product_box">
         <div id="product_cm">
         <h2>
		 <?php echo $row['com_name'];?>
		 </h2>
         <?php echo $row['model_nm'];?>
		 </div>
         <?php echo "<img src='admin/".$row['pro_img'].'" height='150' width='190'></img>";?>
		 <ul>
		 <li> product_id : <?php echo $row['pro_id'];?></li>
		 <li> product_name: <?php echo $row['pro_name'];?></li>
		 <li> PRICE : <?php echo $row['price'];?>RS</li>
		 </ul>
		 <p class="button"><a href="product.php ?  id=<?php echo $row['pro_id'];?>">READ MORE </a></p>
		 </div>
		 <?php 
		 } ?>
		 </div>
		 <?php  include("include/footer.php"); ?>