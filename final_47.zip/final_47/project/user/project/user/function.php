<?php include('include/header1.php');?>
 <link rel="stylesheet" href="../css/style.css"/>
 <html>
 <head>
 <title>mens ware</title>
 </head>
 <body>
 <table width="100%" height="20%" border="1" bgcolor="#CCCC00">
 <tr>
 <td align="left"><h1>mens<fontsize="x1">ware</font>
 <?php if(isset($_SESSION['e_id']))
 {
  ?>
  <div id="user">
  <fontsize="x1">welcome in website,<a href="user_profile.php?id=<?php echo $_SESSION['e_id'];?>">
  <?php echo $_SESSION['user_nm'];?></a>&nbsp;
  
  <a href="logout.php" style="text-transform:capitalize">logout</a>
  </font>
  </div>
  <?php 
  }
  ?>
  </h1>
  </td>
  </tr>
  <td align="right">
  <div id='mbtnavbar'>
  <ul id='mbtnav'>
  
  <?php
  if(isset($_SESSION['e_id'])!='')
  {
    ?>
	<a href="logout.php">Logout</a>
    <?php 
	}
	else
	{ ?>
	<a href="user_login.php">Login</a>
    <?php
	}?>
	<a href="admin/login.php">Admin</a>
    </li>
    </ul>
    </div></td></table>
    </body>
    </div>html>