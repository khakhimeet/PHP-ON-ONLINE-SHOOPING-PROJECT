<?php
$con=mysql_connect("localhost","root","");
$db=mysql_select_db('mensware',$con);
if(isset($_POST['submit']))
{
$unm=$_POST['user_nm'];
$ufnm=$_POST['user_fnm'];
$ulnm=$_POST['user_lnm'];
$eid=$_POST['eid'];
$pwd=$_POST['pwd'];
$con=$_POST['contect_no'];
$add=$_POST['address'];
$ct=$_POST['city'];
$pin=$_POST['pincode'];
$profile_picture=$_POST['profile_picture'];
if($_POST['submit']=='submit')
{
$path="./img/".basename($_FILES['profile_picture']['name']);
		move_uploaded_file($_FILES['profile_picture']['tmp_name'],$path);
		
$qry="insert into register_user(user_nm,user_fnm,user_lnm,eid,pwd,content_no,address,city,pincode,profile_picture)values('$unm','$ufnm','$ulnm','$eid','$pwd','$con','$add','$ct','$pin','$path')";



$res=mysql_query($qry);
if($res)
{
header('location:user_login.php');
}
else
{
echo"not insert";
}
}
else
{
echo"before value is submit";
}
}
?>
<?php include('include/header1.php'); ?>
<html>
<head>
<title>registartion form </title>
<link rel="stylesheet" href="css/register.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" />
</head>
<body>
<div class="container">
<div class="row">
<div class="col-md-10 offset=md-1">
<div class="row">
<div class="col-md-5 register left">
<center><img src="img/6.png" />
<h3> FILL THE FORM </h3>
<marquee><b><u><p>WELCOME TO OUR WEBSITE.....@..PLEASE FILL ALL FIELDS..</P></u></b></marquee>
<button type="button" class="btn btn-primary">About us</button></center>
</div>
<center>
<div class="col-md-7 register right">
<h2> REGISTER HERE </h2>
<div class="register-form">
<div class="form-group">

<form method="post" action="register1.php" enctype="multipart/form-data">


<div class="formrowgrey">
<div class="formleft">
<strong>User Name </strong>
<span id="">*</span>
</div>
<dv class="formright">
<input class="textbox" type="text" id="user_nm" name="user_nm" required />
</div></div>
<div class="formrowgrey">
<div class="formleft">
<strong>First Name </strong>
<span id="">*</span>
</div>
<dv class="formright">
<input class="textbox" type="text" id="user_fnm" name="user_fnm" required />
</div></div>
<div class="formrowgrey">
<div class="formleft">
<strong>Last Name </strong>
<span id="">*</span>
</div>
<dv class="formright">
<input class="textbox" type="text" id="user_lnm" name="user_lnm" required />
</div></div>
<div class="formrow">
<div class="formleft">
<strong>Email id </strong>
<span id="es">*</span>
</div>
<div class="formright">
<input class="textbox" type="text" id="email" name="eid" required />
</div></div>
<div class="formrow">
<div class="formleft">
<strong>Password</strong>
<span id="ps">*</span>
</div>
<div class="formright">
<input class="textbox" type="password" id="pwd" name="pwd" required />
</div></div>
<div class="formrowgrey">
<div class="formleft">
<strong>Contact No</strong>
<span id="">*</span>
</div>
<div class="formright">
<input class="textbox" type="text" id="con" name="contect_no" required />
</div></div>
<div class="formrow">
<div class="formleft">
<strong>Address </strong>
<span id="es">*</span>
</div>
<div class="formright">
<textarea class="textarea" id="add" name="address" rows="5" cols="3" required />
</textarea>
</div></div>
<div class="formrowgrey">
<div class="formleft">
<strong>City</strong>
<span id="">*</span>
</div>
<div class="formright">
<input class="textbox" type="text" id="ct" name="city" required />
</div></div>
<div class="formrow">
<div class="formleft">
<strong>Pin code</strong>
<span id="">*</span>
</div>
<div class="formright">
<input class="textbox" type="text" id="pincode" name="pincode" required />
</div></div>
<div class="formrowgrey">
<div class="formleft">
<strong>Profile_Picture</strong>
<span id="">*</span>
</div>
<div class="formright">
<input class="textbox" type="file" id="pro_img" name="profile_picture" required />
</div></div>
<div class="formrow">
<div class="buttons"><center>
<input class="button_login" type="submit"  name="submit" value="submit"  />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
<input class="button_login" type="reset" name="reset" value="reset" />
</center>
</div></div></div>
</form>
</body>
</html>
<?php include('include/footer1.php');
   ?>
 





















</html>
