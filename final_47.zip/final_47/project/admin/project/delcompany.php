<?php 
$name=$_REQUEST['id'];
$con=mysql_connect("localhost","root","");
$db=mysql_select_db('mensware',$con);
$qry="delete from company where com_id='$name'";
$res=mysql_query($qry);
header('location:company_list.php');
