<?php include('include/header.php');?>
<html>
<head>
<title>mensware</title>
<style>
.slideshow
{
margin:0 auto;
padding-top:50px;
height:700px;
background:#99CCCC;
box-sizing:border-box;
}
.content
{
margin:auto;
width:190px;
perspective:1000px;
position:relative;
padding-top:80px;
}
.content-carrousel
{
width:100px;
position:absolute;
float:right;
animation:rotar 15s infinite linear;
transform-style:preserve-3d;
}
.content-carrousel:hover
{
animation-play-state:paused;
cursor:pointer;
}
.content-carrousel figure
{
width:100%;
height:120px;
border:2px solid #4d444d;
overflow:hidden;
position:absolute;
}
.content-carrousel figure:nth-child(1)
{
transform:rotateY(0deg) translatez(300px);
}
.content-carrousel figure:nth-child(2)
{
transform:rotateY(40deg) translatez(300px);
}
.content-carrousel figure:nth-child(3)
{
transform:rotateY(80deg) translatez(300px);
}
.content-carrousel figure:nth-child(4)
{
transform:rotateY(120deg) translatez(300px);
}
.content-carrousel figure:nth-child(5)
{
transform:rotateY(160deg) translatez(300px);
}
.content-carrousel figure:nth-child(6)
{
transform:rotateY(200deg) translatez(300px);
}
.content-carrousel figure:nth-child(7)
{
   transform:rotateY(240deg)translatez(300px);
}

.content-carrousel figure:nth-child(8)
{
   transform:rotateY(280deg)translatez(300px);
}


.content-carrousel figure:nth-child(9)
{
   transform:rotateY(320deg)translatez(300px);
}

.shadow
{
  position:absolute;
  box-shadow:0px 0px 20px 0px #000;
  border-radius:2px;
  }
  .content-carrousel img
  {
  image-rendering:auto;
  transition:all 300ms;
  width:100%;
  height:100%;
  }
  
  .content-carrousel img: hover
  {
  transform:scale(1.2);
  transition:all 300ms;
  }
  @keyframes rotar
  {
  from
  {
  tranform:rotateY(0deg);
  }
  to
  {
  transform:rotateY(360deg);
  }
  }
  </style>
  </head>
  <body>
  <section class="slideshow">
  <div class="content">
  <div class="content-carrousel">
<figure class="shadow"><a href="company_list.php"><img src="img/1.jpg"></a></figure>
<figure class="shadow"><a href="product_list.php"><img src="img/2.jpg"></a></figure>
<figure class="shadow"><a href=""><img src="img/3.jpg"></a></figure>
<figure class="shadow"><a href="feedback.php"><img src="img/4.jpg"></a></figure>
<figure class="shadow"><a href="order.php"><img src="img/5.gif"></a></figure>
<figure class="shadow"><a href="./admin/login.php"><img src="img/6.png"></a></figure>
<figure class="shadow"><img src="img/7.jpg"></figure>
<figure class="shadow"><img src="img/8.jpg"></figure>
<figure class="shadow"><img src="img/9.png"></figure>
</div>
</div>
</body>
</html>