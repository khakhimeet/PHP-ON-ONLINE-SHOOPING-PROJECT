<?php include('include/header1.php');
include('imagegallery.php'); ?>
<link rel="stylesheet" href="css/style.css" />
<html>
<body>
<div class="yash"></div>


<br/>
<?php include('include/footer1.php');
?>
</body>
</html>
