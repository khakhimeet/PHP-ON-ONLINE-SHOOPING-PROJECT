<?php
$com=mysql_connect("localhost","root","");
$db=mysql_select_db('mensware',$com);
if(isset($_POST['submit']))
{
$com_name=$_POST['com_name'];
if($_POST['submit']=='submit')
{
$qry="insert into company(com_name)values('$com_name')";
$res=mysql_query($qry);
if($res)
{
header('location:company_list.php');
}
else
{
echo"not insert";
}
}
else
{
echo"before value is submit";
}
}
?>
<?php include('include/header.php');?>
<link rel="stylesheet" href="" />
<div id="container">
<div class="shell">
<div id="content">
<div id="round_corner">
<div class="box_head1">add new company</div>
<form method="post" action="addcompany.php">
<div class="formrowgrey">
<div class="formleft">compay name</div>
<div class="formright">
<input type="text" name="com_name" class="textbox" placeholder="company name" />
</div>
</div>
<div class="buttoms">
<input type="submit" name="submit" class="buttom" value="submit" />
<input type="reset" class="buttom" value="reset" />
</div>
</form>
</div>
</div>
</div>
</div>
<?php include('include/footer1.php');?>
