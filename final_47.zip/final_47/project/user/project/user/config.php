<?php
   $con=mysql_connect('localhost','root','');
   mysql_select_db('Online Shopping',$cn);
   include('function.php');
   ?>